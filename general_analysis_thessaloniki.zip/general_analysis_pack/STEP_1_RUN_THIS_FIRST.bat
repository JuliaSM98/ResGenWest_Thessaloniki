@echo off
setlocal enabledelayedexpansion
title ReGenWest - Setup Check

echo.
echo ============================================================
echo   ReGenWest Thessaloniki - Setup Check
echo   Run this ONCE before opening NetLogo.
echo ============================================================
echo.

rem Move to the folder where this file lives (the package root)
cd /d "%~dp0"

set "VENV_DIR=python\.venv"
set "PYTHON_BIN=python\.venv\Scripts\python.exe"
set "REQS_FILE=python\requirements.txt"

rem ---- Step 1: Check Python is installed ----
echo [Step 1/3] Checking Python installation...
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo   ERROR: Python was not found on this computer.
    echo.
    echo   Please:
    echo     1. Go to https://www.python.org/downloads/
    echo     2. Download and install Python
    echo     3. IMPORTANT: tick the box "Add Python to PATH"
    echo        during installation
    echo     4. Run this file again after installing
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo   Found: !PYVER!
echo.

rem ---- Step 2: Create virtual environment ----
echo [Step 2/3] Setting up Python environment...
if exist "%PYTHON_BIN%" (
    echo   Already set up, skipping.
) else (
    python -m venv "%VENV_DIR%"
    if !errorlevel! neq 0 (
        echo.
        echo   ERROR: Could not create Python environment.
        echo   Please contact Julia for help.
        echo.
        pause
        exit /b 1
    )
    echo   Done.
)
echo.

rem ---- Step 3: Install required packages ----
echo [Step 3/3] Installing required packages (fiona, ortools)...
echo   This may take a few minutes on the first run...
echo.
"%PYTHON_BIN%" -m pip install --upgrade pip --quiet
"%PYTHON_BIN%" -m pip install -r "%REQS_FILE%"
if !errorlevel! neq 0 (
    echo.
    echo   ERROR: Could not install the required packages.
    echo   Please contact Julia for help.
    echo.
    pause
    exit /b 1
)
echo.

rem ---- All good ----
echo ============================================================
echo.
echo   SUCCESS! Everything is ready.
echo.
echo   You can now open NetLogo and open the file:
echo       general_analysis.nlogo
echo.
echo   Steps inside NetLogo:
echo     1. Click "setup"
echo     2. Click "go"
echo     3. Use the optimizer buttons whenever you want
echo.
echo ============================================================
echo.
pause
