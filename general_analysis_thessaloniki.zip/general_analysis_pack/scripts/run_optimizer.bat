@echo off
setlocal enabledelayedexpansion

rem ============================================================
rem  run_optimizer.bat  — Windows launcher for the Python optimizer
rem  Called automatically by NetLogo. Do not run this manually.
rem ============================================================

rem Move to the folder that contains this script, then go one level up (repo root)
cd /d "%~dp0.."

set "VENV_DIR=python\.venv"
set "PYTHON_BIN=python\.venv\Scripts\python.exe"
set "REQS_FILE=python\requirements.txt"

rem ---- Set up the Python virtual environment (first run only) ----
if not exist "%PYTHON_BIN%" (
    echo.
    echo [Setup] Setting up Python environment for the first time.
    echo         This may take a few minutes — please wait...
    echo.

    rem Try to find a working Python installation
    where python >nul 2>&1
    if !errorlevel! neq 0 (
        echo.
        echo ERROR: Python was not found on this computer.
        echo Please install Python from https://www.python.org/downloads/
        echo Make sure to tick "Add Python to PATH" during installation.
        echo Then close and re-open NetLogo and try again.
        echo.
        pause
        exit /b 1
    )

    python -m venv "%VENV_DIR%"
    if !errorlevel! neq 0 (
        echo ERROR: Failed to create Python virtual environment.
        pause
        exit /b 1
    )

    "%PYTHON_BIN%" -m pip install --upgrade pip --quiet
    if exist "%REQS_FILE%" (
        echo [Setup] Installing required Python packages (fiona, ortools)...
        "%PYTHON_BIN%" -m pip install -r "%REQS_FILE%"
        if !errorlevel! neq 0 (
            echo ERROR: Failed to install Python packages.
            pause
            exit /b 1
        )
    )
    echo [Setup] Python environment ready.
    echo.
)

rem ---- Run the optimizer ----
"%PYTHON_BIN%" scripts\run_optimizer_win.py
exit /b !errorlevel!
