"""
Windows launcher: reads optimizer args written by NetLogo and runs the optimizer.
Called automatically by run_optimizer.bat — do not run this file directly.
"""
import sys
import os
import subprocess

# Repo root is one level above this script's directory (scripts/)
repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args_file = os.path.join(repo_root, "data", "outputs", "optimizer_args.txt")
python_bin = os.path.join(repo_root, "python", ".venv", "Scripts", "python.exe")

if not os.path.isfile(args_file):
    print("ERROR: Optimizer args file not found:", args_file)
    print("Please click 'setup' in NetLogo first, then try the optimizer button again.")
    sys.exit(1)

# Read one CLI argument per line
args = []
with open(args_file, encoding="utf-8") as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith("#"):
            args.append(line)

# Ensure output directory exists
for a in args:
    if a.startswith("--out="):
        out_path = a[len("--out="):]
        out_dir = os.path.dirname(out_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)

env = os.environ.copy()
env["PYTHONPATH"] = os.path.join(repo_root, "python")

cmd = [python_bin, "-m", "optimizer.cli"] + args
print("Running optimizer:", " ".join(cmd))
result = subprocess.run(cmd, env=env, cwd=repo_root)
sys.exit(result.returncode)
